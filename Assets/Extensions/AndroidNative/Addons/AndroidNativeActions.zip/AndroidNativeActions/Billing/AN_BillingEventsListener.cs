﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Billing")]
	public class AN_BillingEventsListener : FsmStateAction {

		public FsmEvent BillingConnectedEvent;
		public FsmEvent ProductPurchasedEvent;
		public FsmEvent PurchaseFailedEvent;
		public FsmEvent AndroidInventoryLoaded;

	
		public FsmString TransactionProductId;


		
		public override void OnEnter() {

			AndroidInAppPurchaseManager.ActionProductPurchased += ActionProductPurchased;
			AndroidInAppPurchaseManager.ActionBillingSetupFinished += ActionBillingSetupFinished;
			AndroidInAppPurchaseManager.ActionRetrieveProducsFinished += ActionRetrieveProducsFinished;
			
		}

		void ActionProductPurchased (BillingResult res) {
			if (res.isSuccess) {
				TransactionProductId.Value = res.purchase.SKU;

				Fsm.Event (ProductPurchasedEvent);
			}

		}

		void ActionBillingSetupFinished (BillingResult res) {
			if (res.isSuccess) {
				Fsm.Event (BillingConnectedEvent);
			}

		}

		void ActionRetrieveProducsFinished (BillingResult res) {
			if (res.isSuccess) {
				Fsm.Event (AndroidInventoryLoaded);
			}

		}
	}

}
