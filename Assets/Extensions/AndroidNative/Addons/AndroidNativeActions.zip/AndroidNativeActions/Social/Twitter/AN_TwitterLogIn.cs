using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterLogIn : FsmStateAction {

 
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(AndroidTwitterManager.instance.IsAuthed) {
				OnSuccess();
				return;
			}

			AndroidTwitterManager.instance.Init();

			AndroidTwitterManager.instance.addEventListener(TwitterEvents.AUTHENTICATION_SUCCEEDED,  OnSuccess);
			AndroidTwitterManager.instance.addEventListener(TwitterEvents.AUTHENTICATION_FAILED,  	OnFail);

			AndroidTwitterManager.instance.AuthenticateUser();
		}

		private void RemoveListners() {
			AndroidTwitterManager.instance.removeEventListener(TwitterEvents.AUTHENTICATION_SUCCEEDED,  OnSuccess);
			AndroidTwitterManager.instance.removeEventListener(TwitterEvents.AUTHENTICATION_FAILED,  	OnFail);
		}

		private void OnFail() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnSuccess() {

			if(!AndroidTwitterManager.instance.IsAuthed) {
				OnFail();
				return;
			}

			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}

	}
}


