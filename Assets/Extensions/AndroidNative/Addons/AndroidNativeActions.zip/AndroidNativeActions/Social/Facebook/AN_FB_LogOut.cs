using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_LogOut : FsmStateAction {

		public override void OnEnter() {
			SPFacebook.instance.Logout();
			Finish(); 
		}

	}
}


