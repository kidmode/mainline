﻿using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_Analitycs_ActivateApp : FsmStateAction {



		public override void OnEnter() {
			//An app is being activated, typically in the AppDelegate's applicationDidBecomeActive.
			SPFacebookAnalytics.ActivateApp ();
			Finish ();
		}
		
	}
}