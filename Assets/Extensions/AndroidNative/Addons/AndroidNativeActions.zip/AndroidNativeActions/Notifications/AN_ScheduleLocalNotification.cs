﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - Notifications")]
	public class AN_ScheduleLocalNotification : FsmStateAction {

		public FsmString titile;
		public FsmString message;
		public FsmInt secondsDelay;


		public FsmInt scheduledNotificationId;

				
		public override void OnEnter() {
			scheduledNotificationId.Value = AndroidNotificationManager.instance.ScheduleLocalNotification(titile.Value, message.Value, secondsDelay.Value);
			Finish ();
		}
	}
}
